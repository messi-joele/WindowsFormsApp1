﻿namespace WindowsFormsApp1
{
    partial class aggiunta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nome = new System.Windows.Forms.TextBox();
            this.prezzo = new System.Windows.Forms.TextBox();
            this.portata = new System.Windows.Forms.TextBox();
            this.ciao = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Ingrediente1 = new System.Windows.Forms.TextBox();
            this.Ingrediente2 = new System.Windows.Forms.TextBox();
            this.Ingrediente3 = new System.Windows.Forms.TextBox();
            this.Ingrediente4 = new System.Windows.Forms.TextBox();
            this.aggiungi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 41.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(255, 63);
            this.label1.TabIndex = 9;
            this.label1.Text = "Aggiunta";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label4.Location = new System.Drawing.Point(26, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 31);
            this.label4.TabIndex = 10;
            this.label4.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(178, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 31);
            this.label2.TabIndex = 11;
            this.label2.Text = "Prezzo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label3.Location = new System.Drawing.Point(327, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 31);
            this.label3.TabIndex = 12;
            this.label3.Text = "Portata";
            // 
            // nome
            // 
            this.nome.BackColor = System.Drawing.SystemColors.ControlLight;
            this.nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.nome.Location = new System.Drawing.Point(23, 188);
            this.nome.Name = "nome";
            this.nome.Size = new System.Drawing.Size(99, 38);
            this.nome.TabIndex = 13;
            // 
            // prezzo
            // 
            this.prezzo.BackColor = System.Drawing.SystemColors.ControlLight;
            this.prezzo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.prezzo.Location = new System.Drawing.Point(172, 188);
            this.prezzo.Name = "prezzo";
            this.prezzo.Size = new System.Drawing.Size(118, 38);
            this.prezzo.TabIndex = 14;
            // 
            // portata
            // 
            this.portata.BackColor = System.Drawing.SystemColors.ControlLight;
            this.portata.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.portata.Location = new System.Drawing.Point(333, 188);
            this.portata.Name = "portata";
            this.portata.Size = new System.Drawing.Size(112, 38);
            this.portata.TabIndex = 15;
            // 
            // ciao
            // 
            this.ciao.AutoSize = true;
            this.ciao.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.ciao.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.ciao.Location = new System.Drawing.Point(23, 251);
            this.ciao.Name = "ciao";
            this.ciao.Size = new System.Drawing.Size(172, 31);
            this.ciao.TabIndex = 16;
            this.ciao.Text = "Ingrediente 1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label6.Location = new System.Drawing.Point(23, 300);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(172, 31);
            this.label6.TabIndex = 17;
            this.label6.Text = "Ingrediente 2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label7.Location = new System.Drawing.Point(23, 350);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(172, 31);
            this.label7.TabIndex = 18;
            this.label7.Text = "Ingrediente 3";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label8.Location = new System.Drawing.Point(26, 397);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(172, 31);
            this.label8.TabIndex = 19;
            this.label8.Text = "Ingrediente 4";
            // 
            // Ingrediente1
            // 
            this.Ingrediente1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Ingrediente1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Ingrediente1.Location = new System.Drawing.Point(201, 251);
            this.Ingrediente1.Name = "Ingrediente1";
            this.Ingrediente1.Size = new System.Drawing.Size(252, 38);
            this.Ingrediente1.TabIndex = 20;
            // 
            // Ingrediente2
            // 
            this.Ingrediente2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Ingrediente2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Ingrediente2.Location = new System.Drawing.Point(201, 300);
            this.Ingrediente2.Name = "Ingrediente2";
            this.Ingrediente2.Size = new System.Drawing.Size(252, 38);
            this.Ingrediente2.TabIndex = 21;
            // 
            // Ingrediente3
            // 
            this.Ingrediente3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Ingrediente3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Ingrediente3.Location = new System.Drawing.Point(201, 347);
            this.Ingrediente3.Name = "Ingrediente3";
            this.Ingrediente3.Size = new System.Drawing.Size(252, 38);
            this.Ingrediente3.TabIndex = 22;
            // 
            // Ingrediente4
            // 
            this.Ingrediente4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Ingrediente4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Ingrediente4.Location = new System.Drawing.Point(201, 391);
            this.Ingrediente4.Name = "Ingrediente4";
            this.Ingrediente4.Size = new System.Drawing.Size(252, 38);
            this.Ingrediente4.TabIndex = 23;
            // 
            // aggiungi
            // 
            this.aggiungi.Location = new System.Drawing.Point(390, 44);
            this.aggiungi.Name = "aggiungi";
            this.aggiungi.Size = new System.Drawing.Size(75, 23);
            this.aggiungi.TabIndex = 24;
            this.aggiungi.Text = "aggiungi";
            this.aggiungi.UseVisualStyleBackColor = true;
            this.aggiungi.Click += new System.EventHandler(this.aggiungi_Click);
            // 
            // aggiunta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(477, 450);
            this.Controls.Add(this.aggiungi);
            this.Controls.Add(this.Ingrediente4);
            this.Controls.Add(this.Ingrediente3);
            this.Controls.Add(this.Ingrediente2);
            this.Controls.Add(this.Ingrediente1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ciao);
            this.Controls.Add(this.portata);
            this.Controls.Add(this.prezzo);
            this.Controls.Add(this.nome);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Name = "aggiunta";
            this.Text = "aggiunta";
            this.Load += new System.EventHandler(this.aggiunta_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nome;
        private System.Windows.Forms.TextBox prezzo;
        private System.Windows.Forms.TextBox portata;
        private System.Windows.Forms.Label ciao;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Ingrediente1;
        private System.Windows.Forms.TextBox Ingrediente2;
        private System.Windows.Forms.TextBox Ingrediente3;
        private System.Windows.Forms.TextBox Ingrediente4;
        private System.Windows.Forms.Button aggiungi;
    }
}